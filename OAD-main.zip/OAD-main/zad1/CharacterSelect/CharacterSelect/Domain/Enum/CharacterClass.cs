namespace CharacterSelect.Domain.Enum;

public enum CharacterClass
{
    Chieftain = 1,
    Mage = 2,
    Rogue = 3,
    Succubus = 4,
    Neko = 5,
    BattleMaid = 6,
    BunnyGirl = 7
}