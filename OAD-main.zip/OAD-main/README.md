# OAD
Obiektowe Aplikacje Desktopowe
